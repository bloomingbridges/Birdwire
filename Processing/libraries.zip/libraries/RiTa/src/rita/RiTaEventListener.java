package rita;


/**
 * Not required in general usage.
 * @invisible
 * @author dhowe
 */
public interface RiTaEventListener {
  public void onRiTaEvent(RiTaEvent re);
}
