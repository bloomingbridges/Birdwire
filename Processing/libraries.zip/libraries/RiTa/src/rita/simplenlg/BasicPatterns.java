package rita.simplenlg;


// TODO: Auto-generated Javadoc
/**
 * The Class BasicPatterns.
 */
public class BasicPatterns {

	/** The Constant C. */
	public static final String C = "[bcdfghjklmnpqrstvwxyz]";

	/** The Constant V. */
	public static final String V = "[aeiou]";

	/** The Constant VL. */
	public static final String VL = "[lraeiou]";

	/** The Constant VY. */
	public static final String VY = "[yaeiou]";

	/** The Constant VX. */
	public static final String VX = "[xaeiou]";

	/** The Constant ANY_STEM. */
	public static final String ANY_STEM = "^((\\w+)(-\\w+)*)(\\s((\\w+)(-\\w+)*))*$";

	/** The Constant SYLLABLE. */
	public static final String SYLLABLE = "((" + BasicPatterns.C + "{1,3})("
			+ BasicPatterns.VY + "+)(" + BasicPatterns.C + "{0,2}))";

	/** The Constant SYLLABLE_Y. */
	public static final String SYLLABLE_Y = "((" + BasicPatterns.C + "{1,3})y)";

	/** The Constant SYLLABLE_E. */
	public static final String SYLLABLE_E = "((" + BasicPatterns.C + "{1,3})e)";

	/** The Constant VERBAL_PREFIX. */
	public static final String VERBAL_PREFIX = "((be|with|pre|un|over|re|mis|under|out|up|fore|for|counter|co|sub)(-?))";
}
