package rita.simplenlg;

public interface ConjugatorIF {
    
  public String conjugate();
  
  public void setNumber(int i);
  
  public void setTense(int i);
  
  public void setPerson(int i);
  
  public void setPassive(boolean p);
  
  public void setProgressive(boolean p);
  
  public void setPerfect(boolean p);
  
  public void setHead(String v);
}
