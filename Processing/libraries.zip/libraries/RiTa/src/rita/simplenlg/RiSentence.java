package rita.simplenlg;

import java.util.List;


import processing.core.PApplet;
import rita.RiTa;
import rita.RiTaException;
import rita.support.RiSplitter;
import simplenlg.features.Tense;
import simplenlg.realiser.Realiser;
import simplenlg.realiser.SPhraseSpec;

/**
 * Performs sentence level text realization using the specified grammatical elements.<pre>
    RiSentence sent = RiRealizer.createSentence("eat");
    sent.addSubject("John");
    sent.addIndirectObject("Bill's");
    sent.addDirectObject("fruit");
    sent.addPostmodifier("quickly");
    sent.setTense(RiTa.PAST_TENSE);
    sent.setPerfect(true);
    sent.setNegated(true);  
    System.out.println(sent.realize());
    
    // prints -> 'John had not eaten Bill's fruit quickly.'
    </pre>
    Some other options:<pre>    
    sent.setProgressive(true/false);
    sent.setPassive(true/false);    
    sent.addPremodifier(myAdverb);
 */
public class RiSentence
{
  private SPhraseSpec delegate;
  private Realiser realiser;
  
  /** @invisible  */
  public RiSentence(String headVerb) {
    this(null, headVerb);
  }

  public RiSentence(PApplet pApplet, String headVerb) {
    delegate = new SPhraseSpec();
    delegate.setHead(headVerb);
  }

  private static RiSplitter getSplitter() {
    return RiSplitter.getInstance();
  }
  
  /**
   *  Splits the data in <code>text</code> into an array of sentences 
   *  and returns it
   */
  public static String[] splitSentences(String text) 
  {    
    return getSplitter().splitSentences(text); 
  }
  
  /**
   *  Splits the data in <code>text</code> into a List of sentences 
   *  and returns it<P>Note: We split after a period if the following token is capitalized, 
   *  and the preceding token is not a known not-sentence-ending 
   *  abbreviation (such as a title) or a single capital letter.
   */
  public static List splitSentences(List sentences, String text) 
  {
    return getSplitter().splitSentences(sentences, text); 
  }
  
  /**
   * Adds a direct object.<P>For example,
   * <UL>
   * <li> "John eats" (no object)
   * <li> "John eats fruit" (with object)</UL>
   */
  public void addDirectObject(String comp)
  {
    this.delegate.addComplement(comp);
  }
  
  /** 
   * Adds a (beginning of phrase) modifier (in addition to existing frontModifiers).
   */ 
  public void addFrontModifier(String modifier)
  {
    this.delegate.addFrontModifier(modifier);
  }

  /**
   * Adds an indirect object (in addition to existing indirect objects).
   */ 
  public void addIndirectObject(String indirectObject)
  {
    this.delegate.addIndirectObject(indirectObject);
  }
  
  /**
   * Adds a postmodifier to this phrase, in addition to existing
   * postmodifiers.
   * <P>
   * For example,
   * <UL>
   * <li> "John eats" (no postmodifier)
   * <li> "John eats quickly" (with postmodifier)
   * </UL>
   */ 
  public void addPostmodifier(String mod)
  {
    this.delegate.addPostmodifier(mod);
  }
  
  /**
   * Adds a premodifier to this phrase, in addition to existing
   * premodifiers.<P>
   * For example,
   * <UL>
   * <li> "John eats" (no premodifier)
   * <li> "John quickly eats" (with premodifier)
   * </UL>
   */ 
  public void addPremodifier(String mod)
  {
    this.delegate.addPremodifier(mod);
  }

  /**
   * Adds a subjects (in addition to existing subjects). 
   */
  public void addSubject(String sub)
  {
    this.delegate.addSubject(sub);
  }

  /* public void setCuePhrase(String cue)
  {
    this.delegate.setCuePhrase(cue);
  }

  public void setForm(Form f)
  {
    this.delegate.setForm(f);
  }*/

  /**
   * Sets whether the sentence is negated.
   */
  public void setNegated(boolean neg)
  {
    this.delegate.setNegated(neg);
  }

  /**
   * Sets whether the sentence is passive voice.<P>
   * For example,
   * <UL>
   * <li> "John eats an apple" (not passive)
   * <li> "An apple is eaten by John" (passive)
   * </UL>
   */
  public void setPassive(boolean pass)
  {
    this.delegate.setPassive(pass);
  }

  /**
   * Sets whether the phrase is perfective or not.<P>
   * For example,
   * <UL>
   * <li> "John eats" (not perfective)
   * <li> "John has eaten" (perfective)
   * </UL>
   */
  public void setPerfect(boolean perf)
  {
    this.delegate.setPerfect(perf);
  }

  /**
   * Sets whether the sentence has progressive aspect.<P>
   * For example,
   * <UL>
   * <li> "John eats" (not progressive)
   * <li> "John is eating" (progressive)
   * </UL>
   */
  public void setProgressive(boolean prog)
  {
    this.delegate.setProgressive(prog);
  }

  /**
   * Sets the sentence's tense (one of RiTa.FUTURE_TENSE, RiTa.PAST_TENSE, RiTa.PRESENT_TENSE) 
   */
  public void setTense(int tense) {
    switch (tense) {
      case RiTa.FUTURE_TENSE:
        delegate.setTense(Tense.FUTURE);
        break;
      case RiTa.PAST_TENSE:
        delegate.setTense(Tense.PAST);
        break;  
      case RiTa.PRESENT_TENSE:
        delegate.setTense(Tense.PRESENT);
        break;
      default:
        throw new RiTaException("Invalid tense: only RiTa.FUTURE_TENSE,"
          + " RiTa.PAST_TENSE, and RiTa.PRESENT_TENSE are allowed");
    }
  }

  /**
   * Sets the particle for the verb, constructing a phrasal verb such as
   * <i>get <strong>up</strong></i>.
   */
  public void setVerbParticle(String particle)
  {
    this.delegate.setVerbParticle(particle);
  }

  /**
   * Determines whether or not a sentence which has been subordinated 
   * should be expressed using the complementiser or not. <p>
   * This is <i>true</i> by default, yielding sentences such as
   * <i>John said <strong>that Bill kissed Jane</strong></i>. If set to
   * false, the output is <i>John said <strong>Bill kissed Jane</strong></i>.
   * @invisible
   */
  public void suppressComplementiser(boolean suppress)
  {
    this.delegate.suppressComplementiser(suppress);
  }

  /**
   * Sets whether the sentence should render any nominal subjects as 
   * possessive if its form its changed to form gerund. If false,
   * <I>John's kissing Jane</I> becomes <I>John is kissing Jane</I>
   * Defaults to true.   
  public void suppressGenitiveInGerund(boolean suppress)
  {
    this.delegate.suppressGenitiveInGerund(suppress);
  }*/ // NEED TO TEST
  
    /**
   * Produces a String realization of the sentence according
   * to the specified options. 
   */
  public String realize() {
    if (realiser == null)
      realiser = new Realiser();
    return realiser.realise(delegate);
  }
  
  /** @invisible */
  public String toString() { return realize();  }
      
  public static void main(String[] a)
  {
    RiSentence sent = null;//OldRealizer.createSentence("eat");
    //sent.addSubject("John");
    //sent.addSubject("my cat");
   // sent.addSubject("your dog");
    sent.addIndirectObject("Bill's");
    sent.addDirectObject("fruit");
    sent.setTense(RiTa.PAST_TENSE);
    sent.setNegated(true);
    //sent.setProgressive(true);
    //sent.setNegated(true);
    //sent.setPassive(true);
    sent.addPostmodifier("quickly");
    //sent.addPostmodifier("happily");
    sent.setPerfect(true);
    System.out.println(sent.realize());    
  }
 
}// end

