package rita;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import processing.core.PApplet;
import rita.RiHtmlParser.UnicodeHttpFetch;
import rita.support.NGramModel;
import rita.support.ifs.RiSearcherIF;

// IMPLEMENT SERIALIZED CACHING

/*
FACES: Add &imgtype=face to the URL, and enter. Your new face search results will be displayed.
http://images.google.com/images?q=paris&imgtype=face

NEWS:  If you append &imgtype=news to the URL, the new results features images related to the news event.
http://images.google.com/images?q=paris&imgtype=news
*/

/* GOOGLE Stop-Words?
 
    "I
    a
    about
    an
    are
    as
    at
    be
    by
    com
    de
    en
    for
    from
    how
    in
    is
    it
    la
    of
    on
    or
    that
    the
    this
    to
    was
    what
    when
    where
    who
    will
    with
    und
    the
    www"
 */

/**  
 * A utility object for obtaining unigram, bigram, and weighted-bigram counts
 * for words and phrases via the Google search engine. 
 <pre>
      RiGoogleSearch gp = new RiGoogleSearch(this);
      float f = gp.getBigram("canid", "ski'd");</pre>
 */
public class RiGoogleSearch extends RiObject 
{	
  static boolean DBUG = false, DBUG_FETCH = false;
  
  protected static Pattern patResult[], patNoResult;
  protected static boolean cacheEnabled = true;
  protected static Map cache;
  protected static int numCalls;
  
  protected String googleCookie, userAgent, cookiePath;
  protected boolean searchBooks;

  /** @invisible */
  public RiGoogleSearch() 
  {
    this(null);
  } 

  public RiGoogleSearch(PApplet pApplet) 
  {
    super(pApplet);
    
    if (patResult == null) {
      patResult = new Pattern[RESULTS_PATS.length];
      for (int i = 0; i < patResult.length; i++)
      {
        patResult[i] = Pattern.compile(RESULTS_PATS[i]);
      }
    }
  } 
  
  /**
   * Allows the google cookie to be automatically loaded from the file system.
   * As an example, the path for Safari is generally:
   *    '/Users/$userName/Library/Cookies/Cookies.plist'
   */
  public void setLocalCookiePath(String path) {
    
    try {
      new File(path).exists();
    }
    catch (Exception e) {
      
      System.out.println("[WARN] Unable to find cookie file at: "
        +path+"\n"+(e==null?E:e.getMessage()));
      return;
    }
    
    this.cookiePath = path;
    PApplet p = getPApplet();
    
    String contents = RiTa.loadString(p, path);

    String[] cookies = contents.split(END_DICT);
    List cmaps = createCookieMaps(cookies, true);

    String cStr = E;
    for (Iterator iterator = cmaps.iterator(); iterator.hasNext();)
    {
      Map cookie = (Map) iterator.next();
      String name = (String)cookie.get(NAME);
      cStr += name+"="+cookie.get(VALUE)+"; ";
    }
    
    if (!RiTa.SILENT)System.out.println("[INFO] Using Cookie: "+cStr);
    
    googleCookie = cStr;
  }

  private List createCookieMaps(String[] cookies, boolean googleOnly)
  {
    List l = new ArrayList();
    for (int i = 0; i < cookies.length; i++)
    {
      String key = null;
      boolean gotDict = false;
      Map m = new HashMap();
      
      String[] lines = cookies[i].split("\n");
      
      for (int j = 0; j < lines.length; j++)
      {
        String line = RiTa.trimEnds(lines[j]);
        if (line.equals(DICT)) {
          gotDict = true;
          continue;
        }
        if (gotDict) {
          
          if (line.startsWith(KEY)) {
            
            key = line.replaceAll(END_KEY, E);
          }
          else if (line.startsWith(STRING) && key != null) {
            
            m.put(key, line.replaceAll(END_STRING, E));
            key = null;
          }
        }
      }
      if (m.size() > 0) { 
        
        String domain = (String) m.get(DOMAIN);
        if (domain != null) {
          if (!googleOnly || domain.endsWith("google.com"))
            l.add(m);
        }
      }
    }
    return l;
  }
  
  protected void setRequestHeaders2(HttpURLConnection conn) 
  {
    conn.setRequestProperty("User-Agent", DEFAULT_USER_AGENT);
    conn.setRequestProperty("Accept-Language", "en-us,en;q=0.5");
    conn.setRequestProperty("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
    conn.setRequestProperty("Keep-Alive", "300");
    conn.setRequestProperty("Connection", "keep-alive");
    conn.setRequestProperty("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
    conn.setRequestProperty("Referer", "http://www.google.com/");
    if (googleCookie != null) conn.setRequestProperty("Cookie", googleCookie); 
  } 
  
  protected void setRequestHeaders(HttpURLConnection conn) 
  {
    conn.setRequestProperty("User-Agent", DEFAULT_USER_AGENT);
    conn.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
    conn.setRequestProperty("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.3");
    
    conn.setRequestProperty("Connection", "keep-alive");
    conn.setRequestProperty("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
    conn.setRequestProperty("DNT", "1");
    if (googleCookie != null) conn.setRequestProperty("Cookie", googleCookie); 
  } 
  
 
  /**
   * Returns the number of live URL connections made by this object so far
   * @see #setCacheEnabled(boolean)
   */
  public int getCallCount()
  {
    return numCalls;
  }

  /** 
   * Returns the trigram coherence for the word pair where trigram-coherence
   * (w1, w2, w3) = count(w1 + w2 + w3) / (getBigram(w1,w2) + getBigram(w2,w3)))
   * @invisible
   */
  public float getTrigram(String word1, String word2, String word3)
  { 
    // perhaps this should be:
    //   tcount = count(1,2,3) / (count(1,2) + count(2,3) ); 
    //   return tcount / (bigram(1,2) + bigram(2,3));
    if (1==1) throw new RuntimeException("Not yet implemented...");
    long trigram = getCount("\""+word1+" "+word2+" "+word3+"\"");
    float firstPair = getBigram(word1, word2);
    float lastPair  = getBigram(word2, word3);
    return trigram / (firstPair + lastPair);
  }
  
  /** 
   * Returns the bigram coherence for the word pair where
   * coherence(w1, w2) = count(w1 + w2)/(count(w1) + count(w2))
   * [from Gervas]
   */
  public float getBigram(String word1, String word2)
  {        
//System.out.println("RiGoogler.getBigram("+"\""+word1+" "+word2+"\""+")");
    long pair = getCount("\""+word1+" "+word2+"\"");
    if (!DBUG && pair==0) return 0;
    long first = getCount(word1);
    long last = getCount(word2);    

    if (DBUG) {
      System.out.println("getCount1("+word1+") = "+first);
      System.out.println("getCount2("+word2+") = "+last);
      System.out.println("getPair(\""+word1+" "+word2+"\") = "+pair);
      
      if (pair==0) {
        System.out.println("getBigram("+word1+","+word2+") = 0");
        return 0;
      }
    }
        
    float val = pair / (float)(first+last);
    if (DBUG)System.out.println("getBigram("+word1+","+word2+") = "+val);
    return val;
  }
  
  /**
   * Returns the product of the count of the query and the # of words. 
   */
  public float getWeightedUnigram(String query)
  {
    long count = getCount("\""+query+"\"");
    String[] words = query.split(" ");
    if (words == null || words.length<2)
      throw new RiTaException("Invalid input: expect >1 word but got: "+query);
    return count * words.length;    
  }
  
  /**
   * Returns the product of the count of the query and the # of words. 
   */
  public float getWeightedUnigram(String[] words)
  {
    long count = getCount("\""+RiTa.join(words," ")+"\"");
    if (words == null || words.length<2)
      throw new RiTaException("Invalid input: expect >1 word but got: "+RiTa.asList(words));
    return count * words.length;    
  }
  
  /**
   * Returns the product of the avg value of all bigram pairs 
   * and the min bigram value in the sentence. Equivalent to (
   * but more efficient than): getBigramAvg(s) * getBigramMin(s)
   */
  public float getWeightedBigram(String[] sentence)
  {    
    float sum = 0;
    float minVal = Float.MAX_VALUE;
    for (int i = 1; i < sentence.length; i++)  {
      float bg = getBigram(sentence[i-1], sentence[i]);
      if (bg == 0) return 0; 
      if (bg < minVal) minVal = bg;
      sum += bg;
    }
    float avg = sum/(float)(sentence.length-1);
    if (DBUG)System.out.println("avg="+avg+" / min="+minVal);
    return avg * minVal;
  }
  
  /**
   * Returns the avg value of all bigram pairs in
   * the sentence. 
   */
  public float getBigramAvg(String[] sentence)
  {
    float sum = 0;
    for (int i = 1; i < sentence.length; i++)  {      
      sum += getBigram(sentence[i-1], sentence[i]);
//System.out.println("getBigramAvg() = "+sum+"/"+(sentence.length-1));
    }
    return sum/(float)(sentence.length-1);
  }
  
  /**
   * Returns the min value of all bigram pairs in
   * the sentence. 
   */
  public float getBigramMin(String[] sentence)
  {
    float min = Float.MAX_VALUE;
    for (int i = 1; i < sentence.length; i++) { 
      float test = getBigram(sentence[i-1], sentence[i]);
      if (test == 0) return 0;
      if (test < min) min=test;
    }
    return min;
  }
  
  /**
   * Returns the weighted value of all bigram pairs in
   * the sentence. 
   */
  public float getWeightedBigram(List sentence)
  {
    return getWeightedBigram((String[]) sentence.toArray(new String[sentence.size()]));
  }
  
  /**
   * Returns the avg value of all bigram pairs in
   * the sentence. 
   */
  public float getBigramAvg(List sentence)
  {
    return getBigramAvg((String[]) sentence.toArray(new String[sentence.size()]));
  }
  
  /**
   * Returns the min value of all bigram pairs in
   * the sentence. 
   */
  public float getBigramMin(List sentence)
  {
    return getBigramMin((String[]) sentence.toArray(new String[sentence.size()]));
  }
  
  /** @invisible   */
  public String fetch(String queryURL)
  {
    String line = E;
    BufferedReader in = null;
    try
    {
      URL url = new URL(queryURL);
      if (DBUG_FETCH)
        System.out.println("URL: " + queryURL);
      HttpURLConnection conn = (HttpURLConnection) (url.openConnection());
      setRequestHeaders(conn);

      numCalls++;
      try
      {
        in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
      }
      catch (IOException e)
      {
        if (e.getMessage().startsWith(FORBIDDEN_503))
          throw new RiTaException("Google request rejected(503):\n" + queryURL);
      }
      
      StringBuffer sb = new StringBuffer();
      if (in != null) {
        while ((line = in.readLine()) != null)
          sb.append(line + '\n');
      }
      return sb.toString();
    }
    catch (IOException e)
    {
      if (!RiTa.SILENT)
        System.err.println("EXCEPTION: " + e.getClass() + " query=" + queryURL);
      throw new RiTaException("query=" + queryURL, e);
    }
    finally
    {
      try
      {
        if (in != null)
          in.close();
      }
      catch (IOException e)
      {
      }
      in = null;
    }
  }

  /**
   * Returns the number of hits via Google for the search query. To obtain an
   * exact match, place your query in quotes, e.g. <pre>
   *   int k = gp.getCount("\"attained their momentum\"");
   * </pre>
   * @param query The string to be searched for.
   * @return The number of hits Google returned for the search query.
   */
  public int getCount(String query) 
  {
    if (cacheEnabled) // check cache
    {
      if (cache == null)
        cache = new HashMap();
      Integer tmp = (Integer) cache.get(query);
      if (tmp != null)
        return tmp.intValue();
    }

    // fetch html && check against patterns
    String queryURL = makeQuery(query);
    String html = fetch(queryURL);
    int result = checkPatterns(html);

    if (result >= 0)
    {
      if (cacheEnabled) // add to cache
        cache.put(query, new Integer(result));
    }
    else if (DBUG_FETCH)
    {
      writeToFile(html);  // problem! write html to file & exit
      throw new RiTaException("No value (" + result + ") found for "
          + "query: '"+ query +"'\n  writing HTML to google-out.html");
    }

    return result; 
  }

  public int checkPatterns(String line)
  {
    if (line.indexOf(FORBIDDEN_403_PAT) > -1)
      throw new RiTaException("Google request rejected(403): " + line);

    if (line.indexOf("<p>... but your computer or network may be sending automated queries.") > -1)
      throw new RiTaException("Google request rejected(Sorry): " + line);
    
    int result = -1;

    // try the no-result patterns
    for (int i = 0; i < NO_RESULTS.length; i++)
    {
      if (line.indexOf(NO_RESULTS[i]) > -1)
      {
        result = 0;
        break;
      }
    }

    if (result < 0) // no match as yet
    {
      // try our set of count patterns
      for (int i = 0; i < patResult.length; i++)
      {
        result = regexCheck(patResult[i].matcher(line));
        if (result > 0 && !searchBooks)
          break;
      }
    }
    return result;
  }

  public String makeQuery(String query)
  {
    String type = searchBooks ? "books" : "search";

    query = query.replaceAll("\"", "%22");
    query = query.replaceAll(" ", "+");
    String queryURL = "http://www.google.com/" + type + 
        "?hl=en&safe=off&q=" + query + "&btnG=Google+Search";

    return queryURL.replaceAll("%2B", "+");    
  }

  public void writeToFile(String html)
  {
    // file:///Users/dhowe/Documents/eclipse-workspace/RiTaLibrary/google-out.html
    String htmlStr = (html == null) ? "null" : html.toString();
    try
    {
      new FileWriter("google-out.html").write(htmlStr.toString());
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }

  public int regexCheck(Matcher m)
  {
    int result = 0;
    if (m.find()) {
      String countOld = m.group(1);
      StringBuilder countNew = new StringBuilder();
      for (int i = 0; i < countOld.length(); i++) {
        char c = countOld.charAt(i);
        if (c >= '0' && c <= '9')
          countNew.append(c);
      }
      long l = Long.parseLong(countNew.toString());
      result = (l > Integer.MAX_VALUE) ? Integer.MAX_VALUE : (int)l;
    }
    return result;
  }

  /**
   * Returns whether the cache is enabled
   */
  public static boolean isCacheEnabled()
  {
    return cacheEnabled;
  }

  /**
   * Sets whether the cache is enabled and duplicate
   * requests are returned immediately rather than
   * re-contacting google (default=true).
   */
  public static void setCacheEnabled(boolean enableCache)
  {
    cacheEnabled = enableCache;
  }


  /**
   * Returns the current user-agent
   */
  public String getUserAgent()
  {
    return this.userAgent;
  }
  
  /**
   * Sets the user-agent for subsequent requests
   */
  public void setUserAgent(String userAgent)
  {
    this.userAgent = userAgent;
  }

  /**
   * Returns the cookie string used in the last sent query  
   */
  public String getCookie() {
    return this.googleCookie;
  }

  /**
   * Sets the cookie string for subsequent requests 
   */
  public void setCookie(String googleCookie)
  {
    this.googleCookie = googleCookie;
  }  
  
  /**
   * if set to true, searches are restricted to google books
   */
  public void useGoogleBooks(boolean b)
  {
    this.searchBooks = b;
  }
  
  private String[] getImageUrls(String query)
  {
    if (1==1) throw new RuntimeException("not implemented");
    
    String url = "http://www.google.com/search?tbm=isch&hl=en&source=hp&biw=1346&bih=768&q=query&gbv=2&oq=query&aq=f&aqi=g10&aql=&gs_sm=e";
    url = url.replaceAll("##query##", query);
    
    return null;
  }
  
  private List parseRefs(String html, String regex)
  {
    Matcher matcher = Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(html);

    // Get all groups for this pattern
    List matches = new ArrayList();
    while (matcher.find()) {
      String url = matcher.group(1);
      if (1==2) System.err.println("RAW(n): "+url);
      url = decodeUrl(url);
      if (url != null) matches.add(url);
    }
    
    if (matches.size()<1) {
      System.err.println("[WARN] parseRef("+regex+") failed to match...");
    }

    return matches;
  }
  
  private String parseRef(String html, String regex)
  {
    Matcher matcher = Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(html);
    List matches = new ArrayList();
    if (matcher.find())
    {
      String url = matcher.group(1);
      if (1==2) System.err.println("RAW(1): " + url);
      return decodeUrl(url);
    }
    
    return null;
  }

  private String decodeUrl(String url)
  {
    if (url != null) {
      try
      {
        return URLDecoder.decode(url, "UTF8");
      }
      catch (UnsupportedEncodingException e)
      {
        System.err.println(e.getMessage());
      }
    }
    return url;
  }
  
  private String makeCompQuery(String query)
  {
    String type = searchBooks ? "books" : "search";

    query = query.replaceAll(DQ, "%22");
    query = query.replaceAll(SP, "+");
    String queryURL = "http://www.google.com/search?sugexp=chrome,mod=8&sourceid=chrome&ie=UTF-8&q="+query;

    return queryURL.replaceAll("%2B", "+");    
  }
  
  /**
   * @invisible
   */
  public String[] getCompletions(String words)
  {
    return this.getCompletions(words, Integer.MAX_VALUE);
  }
  
  /**
   * Uses google's  "fill in the blank" completion feature to return the missing word(s) in a search...
   * @param pre the term to search before the asterisk
   * @param post the term to search after the asterisk
   */
  public String[] getCompletions(String pre, String post)
  {
    return getCompletions(pre.trim()+" * "+post.trim());
  }
  
  /**
   * Uses google's  "fill in the blank" completion feature to return the subsequent words matched in a search...
   * @param words the term to search
   * @param maxWords the max number of words to return (default=infinity)
   */
  public String[] getCompletions(String words, int maxWords)
  {
    //System.out.println("RiGoogleSearch.getCompletions("+words+","+maxWords+")");

    if (!words.startsWith("\"")) words = DQ + words;
    if (!words.endsWith("\"")) words = words + DQ;
    if (!words.contains("*")) words = words + "*";
    
    String raw = words.replaceAll("[\"]", E).replaceAll("\\s+", SP);
    String parseRE = raw.replaceAll(SP, ".+?").replaceAll("\\*", "(.*)");
    //System.out.println("RE: "+parseRE+" from: '"+raw+"'");
    
    String queryURL = makeCompQuery(words);
    //System.out.println("QUERY: "+queryURL);
    String html = fetch(queryURL);   
    
    List parsed = parseRefs(html, "<em>([^<]+)</em>");
    
    List<String> result = new ArrayList<String>();
    OUTER: for (Iterator it = parsed.iterator(); it.hasNext();)
    {
      String s = (String) it.next();
      
      if (s.contains("*")) continue;

      if ((s = parseRef(s, parseRE)) != null) {
        String ok = RiTa.replaceEntities(s).trim();
        //System.out.println("RAW: "+ok);
        result.add(ok);
      }
    }
    
    String[] arr = result.toArray(new String[result.size()]);
    
    int len = Math.min(arr.length, maxWords);
    if (maxWords< arr.length) joinSubArrays(arr, len);
    
    if (DBUG_FETCH && arr.length < 1)
    {
      writeToFile(html);  // problem! write html to file & exit
      throw new RiTaException("No results found for "
          + "query: '"+ queryURL +"'\n  writing HTML to google-out.html");
    }
    
    return arr;
  }

  private void joinSubArrays(String[] arr, int len)
  {
    for (int i = 0; i < arr.length; i++)
    {
      String[] wds = arr[i].split(SP);
      String[] dst = new String[Math.min(len, wds.length)];
      System.arraycopy(wds, 0, dst, 0, dst.length);
      arr[i] = RiTa.join(dst);
    }
  }
  
  private static NGramModel completionsToNGramModel(String words, String[] results)
  {
    return completionsToNGramModel(words, null, results);
  }
  private static NGramModel completionsToNGramModel(String pre, String post, String[] results)
  {
    String[] longest = null, preToks = null, postToks = null;
    
    if (pre != null) preToks = pre.split(SP);
    if (post != null) postToks = post.split(SP);
    
    List<String[]> tokens = new ArrayList<String[]>();
    for (int i = 0; i < results.length; i++)
    {
      String[] split = results[i].split(SP);
      
      if (longest == null || split.length > longest.length)
        longest = split;
      tokens.add(split);
    }
    int n = preToks.length + longest.length;
    NGramModel ngm = new NGramModel(null, n, true);
    for (Iterator it = tokens.iterator(); it.hasNext();)
    {
      String[] toAdd = add(preToks, (String[]) it.next(), postToks);
      System.out.println("ADD: "+RiTa.asList(toAdd));
      ngm.loadTokens(toAdd);      
    }
    return ngm;
  }

  public static String[] add(String[] a1, String[] a2, String[] a3)
  {
    return add(add(a1,a2),a3);
  }
  
  public static String[] add(String[] a1, String[] a2)
  {
    if (a1 == null && a2 == null) 
      return new String[0];
    if (a1 == null) return a2;
    if (a2 == null) return a1;
    String[] toAdd = new String[a1.length + a2.length];
    for (int i = 0; i < a1.length; i++)
      toAdd[i] = a1[i];
    for (int i = 0; i < a2.length; i++)
      toAdd[i+a1.length] = a2[i];
    return toAdd;
  }

  private static final String FORBIDDEN_503 = "Server returned HTTP response code: 503";
  private static final String FORBIDDEN_403_PAT = "<title>403 Forbidden</title>";
  private static final String DEFAULT_USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5";
  private static final String[] NO_RESULTS = { "No results found for", "</b> - did not match any documents." };
  
  private static final String[] RESULTS_PATS = { 
    " <b>1</b> - <b>(?:[0-9]|10)</b> of (?:about )?<b>([0-9,]+)</b>", 
    ">About ([0-9,]+) results<",
    ">([0-9,]+) results?<" 
  };
  
  
  
  public static void main(String[] args)
  {
/*    System.out.println(RiTa.asList(add(new String[]{"1","2","3"}, new String[]{"5","6"},)));
    if (1==1) return;
*/
    RiGoogleSearch.DBUG_FETCH = true;
    RiGoogleSearch gp = new RiGoogleSearch(null);
    //gp.setLocalCookiePath("/Users/dhowe/Library/Cookies/Cookies.plist");

/*  RiGoogleSearch.DBUG_FETCH = true;
    String text = "hello";//"\"the panting stops tell\" -Beckett";
    System.out.println(gp.getCount(text));    
    if (1==1) return;
    */
    String words = "the cat ate";
    String[] results = gp.getCompletions(words);
    for (int i = 0; i < results.length; i++)
    {
      System.out.println(i+") "+results[i]);
    }
    
    NGramModel model = completionsToNGramModel(words, results);
    //model.printTree();
    
    System.out.println(model.getProbabilities(words.split(SP)));
    
    String pre = "the cat", post = "after the dog";
    results = gp.getCompletions(pre, post);
    for (int i = 0; i < results.length; i++)
    {
      System.out.println(i+") "+results[i]);
    }
    
    model = completionsToNGramModel(pre, post, results);
    //model.printTree();
    
    System.out.println(RiTa.asList(model.getCompletions(pre.split(SP),post.split(SP))));
    
  }



}// end


