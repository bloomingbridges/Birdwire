package rita.support.ifs;


public interface RiStemmerIF
{
  public String stem(String s);
  
  /*public boolean isPlural(String s); 

  public boolean isSingular(String s);
  
  public boolean isSingularAndPlural(String s);*/
  
}