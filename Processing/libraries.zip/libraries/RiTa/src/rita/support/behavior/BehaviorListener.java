package rita.support.behavior;

import rita.RiTextBehavior;

public interface BehaviorListener
{
  public void behaviorCompleted(RiTextBehavior behavior);
}
